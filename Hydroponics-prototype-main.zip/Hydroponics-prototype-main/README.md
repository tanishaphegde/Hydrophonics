# Hydroponics-prototype

using esp8266 and esp32